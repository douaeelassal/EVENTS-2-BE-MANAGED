<?php
header('Location: loading.php');
exit;
?>
